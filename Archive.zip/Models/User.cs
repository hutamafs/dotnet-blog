namespace BlogAPI.Models;

public class User(string username, string email, string pw, string firstName, string? lastName, string? bio)
{
  public int Id;
  public string Username { get; set; } = username;
  public string Email { get; set; } = email;
  public string PasswordHash { get; set; } = pw;
  public string Firstname { get; set; } = firstName;
  public string? Lastname { get; set; } = lastName;
  public string? Bio { get; set; } = bio;
  public DateTime CreatedAt { get; set; } = DateTime.Now;
  public DateTime UpdatedAt { get; set; } = DateTime.Now;

  public List<Post> Posts = [];

}
